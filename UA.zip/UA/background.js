chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'translate') {
    const url = message.url;
    
    // Використовуємо Google Translate API для перекладу сайту
    translatePage(url);
  }
});

function translatePage(url) {
  const googleTranslateURL = `https://translate.google.com/translate?sl=ru&tl=uk&u=${encodeURIComponent(url)}`;
  
  chrome.tabs.update({ url: googleTranslateURL });
}