document.getElementById('translateButton').addEventListener('click', function () {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    const currentTab = tabs[0];
    const url = currentTab.url;

    // Викликаємо фоновий скрипт для перекладу
    chrome.runtime.sendMessage({ action: 'translate', url: url });
  });
});